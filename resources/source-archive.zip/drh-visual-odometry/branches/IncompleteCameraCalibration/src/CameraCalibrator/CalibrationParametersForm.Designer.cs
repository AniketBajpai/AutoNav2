﻿namespace CameraCalibrator
{
	partial class CalibrationParametersForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.m_TextBoxCy = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.m_TextBoxCx = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.m_TextBoxFy = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.m_TextBoxFx = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.m_TextBoxK3 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.m_TextBoxP2 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.m_TextBoxP1 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.m_TextBoxK2 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.m_TextBoxK1 = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.m_ButtonTest = new System.Windows.Forms.Button();
			this.m_ButtonSave = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.m_TextBoxCy);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.m_TextBoxCx);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.m_TextBoxFy);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.m_TextBoxFx);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(12, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(299, 86);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Intrinsic";
			// 
			// m_TextBoxCy
			// 
			this.m_TextBoxCy.Location = new System.Drawing.Point(188, 50);
			this.m_TextBoxCy.Name = "m_TextBoxCy";
			this.m_TextBoxCy.ReadOnly = true;
			this.m_TextBoxCy.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxCy.TabIndex = 7;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(160, 53);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(26, 17);
			this.label3.TabIndex = 6;
			this.label3.Text = "cy:";
			// 
			// m_TextBoxCx
			// 
			this.m_TextBoxCx.Location = new System.Drawing.Point(188, 22);
			this.m_TextBoxCx.Name = "m_TextBoxCx";
			this.m_TextBoxCx.ReadOnly = true;
			this.m_TextBoxCx.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxCx.TabIndex = 5;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(160, 25);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(25, 17);
			this.label4.TabIndex = 4;
			this.label4.Text = "cx:";
			// 
			// m_TextBoxFy
			// 
			this.m_TextBoxFy.Location = new System.Drawing.Point(34, 50);
			this.m_TextBoxFy.Name = "m_TextBoxFy";
			this.m_TextBoxFy.ReadOnly = true;
			this.m_TextBoxFy.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxFy.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 53);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(23, 17);
			this.label2.TabIndex = 2;
			this.label2.Text = "fy:";
			// 
			// m_TextBoxFx
			// 
			this.m_TextBoxFx.Location = new System.Drawing.Point(34, 22);
			this.m_TextBoxFx.Name = "m_TextBoxFx";
			this.m_TextBoxFx.ReadOnly = true;
			this.m_TextBoxFx.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxFx.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(22, 17);
			this.label1.TabIndex = 0;
			this.label1.Text = "fx:";
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.m_TextBoxK3);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this.m_TextBoxP2);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.m_TextBoxP1);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.m_TextBoxK2);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.m_TextBoxK1);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Location = new System.Drawing.Point(12, 104);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(299, 111);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Distortion";
			// 
			// m_TextBoxK3
			// 
			this.m_TextBoxK3.Location = new System.Drawing.Point(34, 77);
			this.m_TextBoxK3.Name = "m_TextBoxK3";
			this.m_TextBoxK3.ReadOnly = true;
			this.m_TextBoxK3.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxK3.TabIndex = 17;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(6, 80);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(27, 17);
			this.label9.TabIndex = 16;
			this.label9.Text = "k3:";
			// 
			// m_TextBoxP2
			// 
			this.m_TextBoxP2.Location = new System.Drawing.Point(188, 49);
			this.m_TextBoxP2.Name = "m_TextBoxP2";
			this.m_TextBoxP2.ReadOnly = true;
			this.m_TextBoxP2.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxP2.TabIndex = 15;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(160, 52);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(28, 17);
			this.label5.TabIndex = 14;
			this.label5.Text = "p2:";
			// 
			// m_TextBoxP1
			// 
			this.m_TextBoxP1.Location = new System.Drawing.Point(188, 21);
			this.m_TextBoxP1.Name = "m_TextBoxP1";
			this.m_TextBoxP1.ReadOnly = true;
			this.m_TextBoxP1.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxP1.TabIndex = 13;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(160, 24);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(28, 17);
			this.label6.TabIndex = 12;
			this.label6.Text = "p1:";
			// 
			// m_TextBoxK2
			// 
			this.m_TextBoxK2.Location = new System.Drawing.Point(34, 49);
			this.m_TextBoxK2.Name = "m_TextBoxK2";
			this.m_TextBoxK2.ReadOnly = true;
			this.m_TextBoxK2.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxK2.TabIndex = 11;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(6, 52);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(27, 17);
			this.label7.TabIndex = 10;
			this.label7.Text = "k2:";
			// 
			// m_TextBoxK1
			// 
			this.m_TextBoxK1.Location = new System.Drawing.Point(34, 21);
			this.m_TextBoxK1.Name = "m_TextBoxK1";
			this.m_TextBoxK1.ReadOnly = true;
			this.m_TextBoxK1.Size = new System.Drawing.Size(100, 22);
			this.m_TextBoxK1.TabIndex = 9;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(6, 24);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(27, 17);
			this.label8.TabIndex = 8;
			this.label8.Text = "k1:";
			// 
			// m_ButtonTest
			// 
			this.m_ButtonTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_ButtonTest.Location = new System.Drawing.Point(155, 228);
			this.m_ButtonTest.Name = "m_ButtonTest";
			this.m_ButtonTest.Size = new System.Drawing.Size(75, 23);
			this.m_ButtonTest.TabIndex = 2;
			this.m_ButtonTest.Text = "Test";
			this.m_ButtonTest.UseVisualStyleBackColor = true;
			this.m_ButtonTest.Click += new System.EventHandler(this.OnTestButtonClick);
			// 
			// m_ButtonSave
			// 
			this.m_ButtonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_ButtonSave.Location = new System.Drawing.Point(236, 228);
			this.m_ButtonSave.Name = "m_ButtonSave";
			this.m_ButtonSave.Size = new System.Drawing.Size(75, 23);
			this.m_ButtonSave.TabIndex = 3;
			this.m_ButtonSave.Text = "Save";
			this.m_ButtonSave.UseVisualStyleBackColor = true;
			this.m_ButtonSave.Click += new System.EventHandler(this.OnButtonSaveClick);
			// 
			// CalibrationParametersForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(323, 263);
			this.Controls.Add(this.m_ButtonSave);
			this.Controls.Add(this.m_ButtonTest);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "CalibrationParametersForm";
			this.Text = "Calibration Parameters";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox m_TextBoxCy;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox m_TextBoxCx;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox m_TextBoxFy;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox m_TextBoxFx;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox m_TextBoxK3;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox m_TextBoxP2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox m_TextBoxP1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox m_TextBoxK2;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox m_TextBoxK1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button m_ButtonTest;
		private System.Windows.Forms.Button m_ButtonSave;
	}
}