﻿namespace CameraCalibrator
{
	partial class CaptureSettingsDialog
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.m_OutputFolderTextBox = new System.Windows.Forms.TextBox();
			this.m_YCountTextBox = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.m_XCountTextBox = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.m_BottomPanel = new System.Windows.Forms.Panel();
			this.m_OKButton = new System.Windows.Forms.Button();
			this.m_CancelButton = new System.Windows.Forms.Button();
			this.m_ImagesCountTextBox = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.m_WaitBetweenCapturesTextBox = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.m_BottomPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(95, 17);
			this.label1.TabIndex = 0;
			this.label1.Text = "Output folder:";
			// 
			// m_OutputFolderTextBox
			// 
			this.m_OutputFolderTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.m_OutputFolderTextBox.Location = new System.Drawing.Point(122, 6);
			this.m_OutputFolderTextBox.Name = "m_OutputFolderTextBox";
			this.m_OutputFolderTextBox.Size = new System.Drawing.Size(321, 22);
			this.m_OutputFolderTextBox.TabIndex = 1;
			// 
			// m_YCountTextBox
			// 
			this.m_YCountTextBox.Location = new System.Drawing.Point(210, 39);
			this.m_YCountTextBox.Name = "m_YCountTextBox";
			this.m_YCountTextBox.Size = new System.Drawing.Size(62, 22);
			this.m_YCountTextBox.TabIndex = 13;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(190, 42);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(14, 17);
			this.label2.TabIndex = 12;
			this.label2.Text = "x";
			// 
			// m_XCountTextBox
			// 
			this.m_XCountTextBox.Location = new System.Drawing.Point(122, 39);
			this.m_XCountTextBox.Name = "m_XCountTextBox";
			this.m_XCountTextBox.Size = new System.Drawing.Size(62, 22);
			this.m_XCountTextBox.TabIndex = 11;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 42);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(101, 17);
			this.label3.TabIndex = 10;
			this.label3.Text = "Checkerboard:";
			// 
			// m_BottomPanel
			// 
			this.m_BottomPanel.Controls.Add(this.m_OKButton);
			this.m_BottomPanel.Controls.Add(this.m_CancelButton);
			this.m_BottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.m_BottomPanel.Location = new System.Drawing.Point(0, 137);
			this.m_BottomPanel.Name = "m_BottomPanel";
			this.m_BottomPanel.Size = new System.Drawing.Size(455, 43);
			this.m_BottomPanel.TabIndex = 14;
			// 
			// m_OKButton
			// 
			this.m_OKButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_OKButton.Location = new System.Drawing.Point(287, 8);
			this.m_OKButton.Name = "m_OKButton";
			this.m_OKButton.Size = new System.Drawing.Size(75, 23);
			this.m_OKButton.TabIndex = 1;
			this.m_OKButton.Text = "OK";
			this.m_OKButton.UseVisualStyleBackColor = true;
			this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClicked);
			// 
			// m_CancelButton
			// 
			this.m_CancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.m_CancelButton.Location = new System.Drawing.Point(368, 8);
			this.m_CancelButton.Name = "m_CancelButton";
			this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
			this.m_CancelButton.TabIndex = 0;
			this.m_CancelButton.Text = "Cancel";
			this.m_CancelButton.UseVisualStyleBackColor = true;
			this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClicked);
			// 
			// m_ImagesCountTextBox
			// 
			this.m_ImagesCountTextBox.Location = new System.Drawing.Point(122, 71);
			this.m_ImagesCountTextBox.Name = "m_ImagesCountTextBox";
			this.m_ImagesCountTextBox.Size = new System.Drawing.Size(62, 22);
			this.m_ImagesCountTextBox.TabIndex = 16;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(12, 74);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(89, 17);
			this.label4.TabIndex = 15;
			this.label4.Text = "Image count:";
			// 
			// m_WaitBetweenCapturesTextBox
			// 
			this.m_WaitBetweenCapturesTextBox.Location = new System.Drawing.Point(122, 101);
			this.m_WaitBetweenCapturesTextBox.Name = "m_WaitBetweenCapturesTextBox";
			this.m_WaitBetweenCapturesTextBox.Size = new System.Drawing.Size(150, 22);
			this.m_WaitBetweenCapturesTextBox.TabIndex = 18;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(84, 17);
			this.label5.TabIndex = 17;
			this.label5.Text = "Wait period:";
			// 
			// CaptureSettingsDialog
			// 
			this.AcceptButton = this.m_OKButton;
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.m_CancelButton;
			this.ClientSize = new System.Drawing.Size(455, 180);
			this.Controls.Add(this.m_WaitBetweenCapturesTextBox);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.m_ImagesCountTextBox);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.m_BottomPanel);
			this.Controls.Add(this.m_YCountTextBox);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.m_XCountTextBox);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.m_OutputFolderTextBox);
			this.Controls.Add(this.label1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CaptureSettingsDialog";
			this.Text = "Capture Settings";
			this.m_BottomPanel.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox m_OutputFolderTextBox;
		private System.Windows.Forms.TextBox m_YCountTextBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox m_XCountTextBox;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel m_BottomPanel;
		private System.Windows.Forms.Button m_OKButton;
		private System.Windows.Forms.Button m_CancelButton;
		private System.Windows.Forms.TextBox m_ImagesCountTextBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox m_WaitBetweenCapturesTextBox;
		private System.Windows.Forms.Label label5;
	}
}